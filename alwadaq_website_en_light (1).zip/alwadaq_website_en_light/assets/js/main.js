
(function(){
 const y=document.getElementById("year");
 if(y) y.textContent=new Date().getFullYear();
 const path=(location.pathname.split("/").pop()||"index.html");
 document.querySelectorAll("[data-nav]").forEach(a=>{
   if(a.getAttribute("href")===path) a.classList.add("active");
 });
 const f=document.getElementById("contactForm");
 if(f){
   f.addEventListener("submit",e=>{
     e.preventDefault();
     alert("Message sent (demo).");
     f.reset();
   });
 }
})();
